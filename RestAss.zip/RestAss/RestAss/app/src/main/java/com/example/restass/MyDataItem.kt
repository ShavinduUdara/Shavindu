package com.example.restass

data class MyDataItem(
    val body: String,
    val id: Int,
    val title: String,
    val userId: Int
)