package com.example.restass

class MyData : ArrayList<MyDataItem>()