package com.hrandika.android.seng22243intro.model

data class User(val id: Number, val name: String, val username: String, val email: String)